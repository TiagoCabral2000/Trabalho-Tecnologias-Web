// BLUENAV -> BLUENAV FIXA *****************************************************************************************
var blueNav = document.querySelector('.blue-nav');
var whiteNav = document.querySelector('.white-nav');  
var BtnHamb = document.querySelector('.btn-hamburguer');
var dropdownMainmenu = document.querySelector('dropdown-minimized-mainmenu');
var dropdownAbout = document.querySelector('dropdown-minimized-about');

function checkScroll() {
    var scrollPosition = window.scrollY; // Verifica a posição vertical do site em que o utilizador está

    var whiteNavHeight = whiteNav.offsetHeight; //retorna a altura da whitenav, incluindo altura, margens e bordas (exclui padding)

    if (scrollPosition >= whiteNavHeight) { // Verifica se a posição de rolagem ultrapassou a altura da .white-nav
        blueNav.classList.add('blue-nav-fixa'); // Adiciona a classe .blue-nav-fixa quando descer além da .white-nav
    }
    else {
        blueNav.classList.remove('blue-nav-fixa'); // Remove a classe .blue-nav-fixa quando voltar acima da .white-nav
    }
}

function showmainmenu(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="flex"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
function showabout(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="flex" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function showwhatwedo(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="flex" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function showemergencies(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="flex" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function shownewsandstories(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="flex" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function showgetinvolved(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="flex"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function show_overview(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="flex"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
////// ajs"""//
function show_wherewework(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"

    document.getElementById('dropdown-minimized-wherewework').style.display="flex"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
}
function show_whoweprotect(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="flex"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
function show_ourpartners(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="flex"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
function show_governanceandoversight(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="flex"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
function show_respondtoemergencies(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="flex"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"
    

}
function show_protecthumanrights(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="flex"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"   

}
function show_buildbetterfutures(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="flex"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"   

}
function show_forumsandcomittes(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="flex"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none" 
    

}
function show_reportsandpublications(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="flex" 
    

}

function closeall(){
    document.getElementById('dropdown-minimized-mainmenu').style.display="none"
    document.getElementById('dropdown-minimized-about').style.display="none" 
    document.getElementById('dropdown-minimized-whatwedo').style.display="none" 
    document.getElementById('dropdown-minimized-emergencies').style.display="none" 
    document.getElementById('dropdown-minimized-newsandstories').style.display="none" 
    document.getElementById('dropdown-minimized-getinvolved').style.display="none"
    document.getElementById('dropdown-minimized-overview').style.display="none"
    document.getElementById('dropdown-minimized-wherewework').style.display="none"
    document.getElementById('dropdown-minimized-whoweprotect').style.display="none"
    document.getElementById('dropdown-minimized-ourpartners').style.display="none"
    document.getElementById('dropdown-minimized-governanceandoversight').style.display="none"
    document.getElementById('dropdown-minimized-respondtoemergencies').style.display="none"
    document.getElementById('dropdown-minimized-protecthumanrights').style.display="none"
    document.getElementById('dropdown-minimized-buildbetterfutures').style.display="none"
    document.getElementById('dropdown-minimized-forumsandcomittes').style.display="none"
    document.getElementById('dropdown-minimized-reportsandpublications').style.display="none"

}
